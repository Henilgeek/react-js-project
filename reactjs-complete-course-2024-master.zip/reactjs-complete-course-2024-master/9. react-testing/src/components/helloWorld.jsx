function HelloWorld() {
  return (
    <div>
      <h1>Hello World</h1>
      <p data-testid="name">Sangam Mukherjee</p>
    </div>
  );
}

export default HelloWorld;
