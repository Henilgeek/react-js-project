// function FunctionalComponent() {
//   return (
//     <div>
//       <h4>Functional component</h4>
//     </div>
//   );
// }

const FunctionalComponent = () => {
  return (
    <div>
      <h4>Functional component</h4>
    </div>
  );
};

export default FunctionalComponent;
